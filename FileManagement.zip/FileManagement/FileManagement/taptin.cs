﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileManagement
{
    class taptin
    {
        public taptin()
        {

        }
  
        public taptin(string name, string type, DateTime time, string path)
        {
            this.name = name;
            this.type = type;
            this.time = time;
            this.path = path;
        }

        public string name { get; set; }
        public string type { get; set; }
        public DateTime time { get; set; }
        public string path { get; set; }

    }
}
