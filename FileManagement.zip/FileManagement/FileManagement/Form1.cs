﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Elasticsearch.Net;
using Nest;

namespace FileManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TxtbPath_TextChanged(object sender, EventArgs e)
        {
            setButtonVisibility();
        }

        private void setButtonVisibility()
        {
            if ((txtbPath.Text != String.Empty))
            {
                bttStart.Enabled = true;

            }
            else
            {
                bttStart.Enabled = false;

            }

        }

        private void BttStart_Click(object sender, EventArgs e)
        {
            IElasticClient _client = new ElasticClient();
            string path = $@"{txtbPath.Text}";
            List<taptin> filelist = new List<taptin>();
            var dirInfo = new DirectoryInfo(path);
            if (dirInfo.Exists)
            {
                FileInfo[] files = dirInfo.GetFiles("*.*", SearchOption.AllDirectories);
                foreach (FileInfo currentFile in files)
                {
                    taptin tmpfile = new taptin();
                    tmpfile.name = currentFile.Name;
                    tmpfile.type = currentFile.Extension;
                    tmpfile.time = currentFile.CreationTime;
                    tmpfile.path = currentFile.FullName;
                    filelist.Add(tmpfile);
                    _client.Index(tmpfile, i => i.Index("duyindex"));
                    _client.Index(new IndexRequest<taptin>(tmpfile, "duyindex"));
                   
                    System.Diagnostics.Debug.WriteLine(tmpfile.name);
                }

            }
            
        }
    }
}
